# ADB TV Remote

App Android điều khiển TV box / Android TV qua **ADB over network** (tương tự app "ADB Remote").
Viết bằng Kotlin + Jetpack Compose, dùng thư viện [dadb](https://github.com/mobile-dev-inc/dadb) làm ADB client (không cần root, không cần binary `adb`).

## Tính năng

- Kết nối bằng IP:cổng (mặc định 5555), lưu danh sách thiết bị, **quét mạng LAN** tìm TV box mở cổng 5555
- D-pad (giữ để lặp phím) + OK, hoặc chế độ **Touchpad** (vuốt/chạm)
- Nguồn, Nguồn vào (TV Input), Tắt tiếng, Cài đặt, Back, Home, Menu
- Âm lượng +/- và Kênh +/- (giữ để lặp), Play/Pause, Stop, Tua tới/lùi, Bài trước/sau
- Bàn phím số 0-9
- Danh sách ứng dụng đã cài (lọc/tìm), chạm để mở app (hỗ trợ cả LAUNCHER và LEANBACK)
- Gửi văn bản lên TV (`input text`), Enter, Xóa
- Lệnh nhanh: Cài đặt, Wi-Fi, Tùy chọn nhà phát triển, Đánh thức/Ngủ, Khởi động lại
- Console chạy lệnh `adb shell` bất kỳ
- Chụp màn hình TV (`screencap`) và xem ngay trong app

## Chuẩn bị trên TV box

1. Cài đặt → Giới thiệu → bấm 7 lần vào **Số bản dựng** để bật Tùy chọn nhà phát triển.
2. Bật **Gỡ lỗi USB** (và **Gỡ lỗi ADB qua mạng / ADB over network** nếu có).
3. Lấy địa chỉ IP của TV box (Cài đặt → Mạng).
4. Điện thoại và TV box phải cùng mạng Wi-Fi/LAN.
5. Lần kết nối đầu, TV hiện hộp thoại "Cho phép gỡ lỗi USB?" → chọn **Luôn cho phép**.

Nếu TV box không có mục "ADB qua mạng", cắm USB vào máy tính một lần rồi chạy `adb tcpip 5555`.

## Build ra APK

### Cách 1: Android Studio
Mở thư mục này bằng Android Studio (Koala trở lên) → chờ Gradle sync → **Build → Build APK(s)**.
File ra tại `app/build/outputs/apk/debug/app-debug.apk`.

### Cách 2: Dòng lệnh (cần JDK 17 + Android SDK)
```
./gradlew assembleDebug
```

### Cách 3: GitHub Actions (không cần cài gì)
Đẩy project lên một repo GitHub → tab **Actions** → workflow **Build APK** chạy tự động
(hoặc bấm *Run workflow*) → tải artifact **AdbTvRemote-debug-apk**.

APK debug đã được ký bằng khóa debug nên cài thẳng được (bật "Cài app không rõ nguồn gốc").

## Hạn chế

- Chưa hỗ trợ **ghép đôi bằng mã** (Wireless debugging của Android 11+); dùng ADB TCP cổng 5555 như hầu hết TV box.
- `input text` chỉ gõ được ký tự ASCII, không gõ được tiếng Việt có dấu.
- minSdk 26 (Android 8.0 trở lên) cho điện thoại điều khiển.

## Cấu trúc

```
app/src/main/java/com/tvremote/adb/
  AdbManager.kt      kết nối ADB (dadb), shell, screenshot, quét LAN
  RemoteViewModel.kt trạng thái + hành động
  DeviceStore.kt     lưu thiết bị
  Keys.kt            mã phím Android
  Ui.kt              giao diện Compose
  MainActivity.kt
```
