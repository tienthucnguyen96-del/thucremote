package com.tvremote.adb

/** Android KeyEvent codes dùng với `input keyevent`. */
object Keys {
    const val BACK = 4
    const val HOME = 3
    const val MENU = 82
    const val POWER = 26
    const val UP = 19
    const val DOWN = 20
    const val LEFT = 21
    const val RIGHT = 22
    const val CENTER = 23
    const val ENTER = 66
    const val DEL = 67
    const val VOL_UP = 24
    const val VOL_DOWN = 25
    const val MUTE = 164
    const val PLAY_PAUSE = 85
    const val STOP = 86
    const val NEXT = 87
    const val PREV = 88
    const val REWIND = 89
    const val FAST_FORWARD = 90
    const val CH_UP = 166
    const val CH_DOWN = 167
    const val TV_INPUT = 178
    const val SETTINGS = 176

    /** Phím số 0..9 -> KEYCODE_0 (7) .. KEYCODE_9 (16) */
    fun digit(n: Int) = 7 + n
}
