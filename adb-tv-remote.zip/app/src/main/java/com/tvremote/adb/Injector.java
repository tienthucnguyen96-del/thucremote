package com.tvremote.adb;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.KeyEvent;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

/**
 * Tiến trình nhỏ chạy trên TV box (qua app_process, quyền shell) để chèn phím nhanh.
 * Giao thức qua stdin/stdout:
 *   in : "k 19 20 66"   -> bấm lần lượt các phím có mã 19, 20, 66
 *   out: "@@READY@@" khi sẵn sàng, "@@K@@" sau mỗi dòng lệnh đã xử lý xong.
 * Chỉ dùng reflection nên không cần hidden-API stub khi biên dịch.
 */
public final class Injector {
    private static Object manager;
    private static Method injectMethod;

    private static void init() throws Exception {
        String[] names = {
                "android.hardware.input.InputManagerGlobal", // Android 14+
                "android.hardware.input.InputManager"        // Android <= 13
        };
        Throwable last = null;
        for (String name : names) {
            try {
                Class<?> cls = Class.forName(name);
                Method getInstance = cls.getDeclaredMethod("getInstance");
                getInstance.setAccessible(true);
                Object instance = getInstance.invoke(null);
                Method inject = cls.getMethod("injectInputEvent", InputEvent.class, int.class);
                manager = instance;
                injectMethod = inject;
                return;
            } catch (Throwable t) {
                last = t;
            }
        }
        throw new Exception("Không tìm được InputManager: " + last);
    }

    private static void press(int code) throws Exception {
        long now = SystemClock.uptimeMillis();
        KeyEvent down = new KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0, 0, -1, 0, 0,
                InputDevice.SOURCE_KEYBOARD);
        injectMethod.invoke(manager, down, 0);
        long later = SystemClock.uptimeMillis();
        KeyEvent up = new KeyEvent(now, later, KeyEvent.ACTION_UP, code, 0, 0, -1, 0, 0,
                InputDevice.SOURCE_KEYBOARD);
        injectMethod.invoke(manager, up, 0);
    }

    public static void main(String[] args) {
        try {
            init();
            press(0); // tự kiểm tra quyền chèn phím (KEYCODE_UNKNOWN, vô hại)
        } catch (Throwable t) {
            t.printStackTrace();
            System.exit(1);
            return;
        }
        System.out.println("@@READY@@");
        System.out.flush();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split("\\s+");
                if (parts.length > 1 && parts[0].equals("k")) {
                    for (int i = 1; i < parts.length; i++) {
                        try {
                            press(Integer.parseInt(parts[i]));
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }
                }
                System.out.println("@@K@@");
                System.out.flush();
            }
        } catch (Throwable ignored) {
        }
    }
}
