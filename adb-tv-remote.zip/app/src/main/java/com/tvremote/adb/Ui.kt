package com.tvremote.adb

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

// =====================================================================
// Root
// =====================================================================

@Composable
fun AppRoot(vm: RemoteViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(ui.message) {
        ui.message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize()) {
            if (ui.connected) MainScreen(vm, ui) else ConnectScreen(vm, ui)
            SnackbarHost(
                snackbar,
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = if (ui.connected) 88.dp else 8.dp),
            )
        }
    }
}

// =====================================================================
// Màn hình kết nối
// =====================================================================

@Composable
fun ConnectScreen(vm: RemoteViewModel, ui: UiState) {
    var host by rememberSaveable { mutableStateOf(ui.devices.lastOrNull()?.host ?: "") }
    var port by rememberSaveable { mutableStateOf(ui.devices.lastOrNull()?.port?.toString() ?: "5555") }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Column(Modifier.padding(top = 24.dp)) {
                Text("ADB TV Remote", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Điều khiển TV box Android qua ADB. Bật \"Gỡ lỗi USB / ADB qua mạng\" trên TV box, " +
                        "rồi nhập IP của nó. Lần đầu hãy bấm \"Cho phép\" trên màn hình TV.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    host, { host = it },
                    modifier = Modifier.weight(1f),
                    label = { Text("Địa chỉ IP") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                )
                OutlinedTextField(
                    port, { port = it.filter { c -> c.isDigit() }.take(5) },
                    modifier = Modifier.width(100.dp),
                    label = { Text("Cổng") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            }
        }
        item {
            Button(
                onClick = { vm.connect(host, port.toIntOrNull() ?: 5555) },
                enabled = !ui.connecting,
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (ui.connecting) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Đang kết nối…")
                } else {
                    Text("Kết nối")
                }
            }
        }
        item {
            OutlinedButton(
                onClick = { vm.scan() },
                enabled = !ui.scanning,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Filled.Search, null)
                Spacer(Modifier.width(8.dp))
                Text(if (ui.scanning) "Đang quét mạng…" else "Quét mạng tìm TV box (cổng 5555)")
            }
        }
        if (ui.found.isNotEmpty()) {
            item { Text("Tìm thấy trong mạng", style = MaterialTheme.typography.titleSmall) }
            items(ui.found, key = { "found-$it" }) { ip ->
                ListItem(
                    headlineContent = { Text(ip) },
                    supportingContent = { Text("Chạm để điền vào ô IP") },
                    modifier = Modifier.clickable {
                        host = ip
                        port = "5555"
                    },
                )
            }
        }
        if (ui.devices.isNotEmpty()) {
            item { Text("Thiết bị đã lưu", style = MaterialTheme.typography.titleSmall) }
            items(ui.devices.reversed(), key = { "saved-${it.host}:${it.port}" }) { d ->
                ListItem(
                    headlineContent = { Text(d.name) },
                    supportingContent = { Text("${d.host}:${d.port}") },
                    trailingContent = {
                        IconButton(onClick = { vm.forget(d) }) { Icon(Icons.Filled.Delete, "Xóa") }
                    },
                    modifier = Modifier.clickable(enabled = !ui.connecting) { vm.connect(d.host, d.port) },
                )
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

// =====================================================================
// Màn hình chính (sau khi kết nối)
// =====================================================================

private data class TabDef(val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabDef("Điều khiển", Icons.Filled.Gamepad),
    TabDef("Ứng dụng", Icons.Filled.Apps),
    TabDef("Nhập liệu", Icons.Filled.Keyboard),
    TabDef("Màn hình", Icons.Filled.PhotoCamera),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: RemoteViewModel, ui: UiState) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(ui.deviceName, style = MaterialTheme.typography.titleMedium)
                        Text(ui.host, style = MaterialTheme.typography.bodySmall)
                    }
                },
                actions = {
                    IconButton(onClick = { vm.disconnect() }) {
                        Icon(Icons.Filled.Close, "Ngắt kết nối")
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, null) },
                        label = { Text(t.label) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> RemoteTab(vm)
                1 -> AppsTab(vm, ui)
                2 -> InputTab(vm, ui)
                else -> ScreenTab(vm, ui)
            }
        }
    }
}

// =====================================================================
// Tab điều khiển
// =====================================================================

@Composable
fun PressSurface(
    modifier: Modifier,
    shape: Shape,
    color: Color,
    repeat: Boolean,
    onKey: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val current by rememberUpdatedState(onKey)
    var pressed by remember { mutableStateOf(false) }
    Box(
        modifier
            .clip(shape)
            .background(if (pressed) color.copy(alpha = 0.55f) else color)
            .pointerInput(repeat) {
                detectTapGestures(onPress = {
                    pressed = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    current()
                    if (repeat) {
                        coroutineScope {
                            val job = launch {
                                delay(400)
                                while (true) {
                                    current()
                                    delay(110)
                                }
                            }
                            tryAwaitRelease()
                            job.cancel()
                        }
                    } else {
                        tryAwaitRelease()
                    }
                    pressed = false
                })
            },
        contentAlignment = Alignment.Center,
        content = content,
    )
}

@Composable
fun KeyBtn(
    icon: ImageVector,
    desc: String,
    onKey: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    repeat: Boolean = false,
    container: Color = MaterialTheme.colorScheme.secondaryContainer,
    tint: Color = MaterialTheme.colorScheme.onSecondaryContainer,
) {
    PressSurface(modifier.size(size), CircleShape, container, repeat, onKey) {
        Icon(icon, desc, tint = tint)
    }
}

@Composable
fun TextKeyBtn(label: String, onKey: () -> Unit, modifier: Modifier = Modifier, size: Dp = 56.dp) {
    PressSurface(
        modifier.size(size), CircleShape, MaterialTheme.colorScheme.secondaryContainer, false, onKey,
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun RemoteTab(vm: RemoteViewModel) {
    var touchpad by rememberSaveable { mutableStateOf(false) }
    var numpad by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            KeyBtn(
                Icons.Filled.PowerSettingsNew, "Nguồn", { vm.key(Keys.POWER) },
                container = MaterialTheme.colorScheme.errorContainer,
                tint = MaterialTheme.colorScheme.onErrorContainer,
            )
            KeyBtn(Icons.Filled.Tv, "Nguồn vào", { vm.key(Keys.TV_INPUT) })
            KeyBtn(Icons.Filled.VolumeOff, "Tắt tiếng", { vm.key(Keys.MUTE) })
            KeyBtn(Icons.Filled.Settings, "Cài đặt", { vm.key(Keys.SETTINGS) })
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !touchpad, onClick = { touchpad = false }, label = { Text("D-pad") })
            FilterChip(selected = touchpad, onClick = { touchpad = true }, label = { Text("Touchpad") })
        }

        if (touchpad) TouchPad(vm) else DPad(vm)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            KeyBtn(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", { vm.key(Keys.BACK) })
            KeyBtn(Icons.Filled.Home, "Home", { vm.key(Keys.HOME) })
            KeyBtn(Icons.Filled.Menu, "Menu", { vm.key(Keys.MENU) })
        }

        // Âm lượng / Kênh
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            RockerPair(
                label = "VOL",
                up = { vm.key(Keys.VOL_UP) }, down = { vm.key(Keys.VOL_DOWN) },
                upIcon = Icons.Filled.VolumeUp, downIcon = Icons.Filled.VolumeDown,
            )
            RockerPair(
                label = "CH",
                up = { vm.key(Keys.CH_UP) }, down = { vm.key(Keys.CH_DOWN) },
                upIcon = Icons.Filled.KeyboardArrowUp, downIcon = Icons.Filled.KeyboardArrowDown,
            )
        }

        // Media
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            KeyBtn(Icons.Filled.SkipPrevious, "Bài trước", { vm.key(Keys.PREV) }, size = 48.dp)
            KeyBtn(Icons.Filled.FastRewind, "Tua lùi", { vm.key(Keys.REWIND) }, size = 48.dp)
            KeyBtn(
                Icons.Filled.PlayArrow, "Phát/Tạm dừng", { vm.key(Keys.PLAY_PAUSE) }, size = 56.dp,
                container = MaterialTheme.colorScheme.primaryContainer,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            KeyBtn(Icons.Filled.FastForward, "Tua tới", { vm.key(Keys.FAST_FORWARD) }, size = 48.dp)
            KeyBtn(Icons.Filled.SkipNext, "Bài sau", { vm.key(Keys.NEXT) }, size = 48.dp)
        }
        KeyBtn(Icons.Filled.Stop, "Dừng", { vm.key(Keys.STOP) }, size = 44.dp)

        TextButton(onClick = { numpad = !numpad }) {
            Icon(Icons.Filled.Dialpad, null)
            Spacer(Modifier.width(8.dp))
            Text(if (numpad) "Ẩn bàn phím số" else "Bàn phím số")
        }
        if (numpad) NumPad(vm)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun RockerPair(
    label: String,
    up: () -> Unit,
    down: () -> Unit,
    upIcon: ImageVector,
    downIcon: ImageVector,
) {
    val shape = RoundedCornerShape(32.dp)
    Column(
        Modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        KeyBtn(
            upIcon, "$label +", up, repeat = true, size = 56.dp,
            container = Color.Transparent, tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        KeyBtn(
            downIcon, "$label -", down, repeat = true, size = 56.dp,
            container = Color.Transparent, tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun DPad(vm: RemoteViewModel) {
    val ring = MaterialTheme.colorScheme.surfaceVariant
    val btn = MaterialTheme.colorScheme.surface
    val tint = MaterialTheme.colorScheme.onSurface
    Box(
        Modifier
            .size(264.dp)
            .clip(CircleShape)
            .background(ring),
    ) {
        Column(
            Modifier.fillMaxSize().padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            KeyBtn(Icons.Filled.KeyboardArrowUp, "Lên", { vm.key(Keys.UP) }, size = 68.dp, repeat = true, container = btn, tint = tint)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                KeyBtn(Icons.Filled.KeyboardArrowLeft, "Trái", { vm.key(Keys.LEFT) }, size = 68.dp, repeat = true, container = btn, tint = tint)
                PressSurface(
                    Modifier.size(84.dp), CircleShape, MaterialTheme.colorScheme.primary, false,
                    { vm.key(Keys.CENTER) },
                ) {
                    Text("OK", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge)
                }
                KeyBtn(Icons.Filled.KeyboardArrowRight, "Phải", { vm.key(Keys.RIGHT) }, size = 68.dp, repeat = true, container = btn, tint = tint)
            }
            KeyBtn(Icons.Filled.KeyboardArrowDown, "Xuống", { vm.key(Keys.DOWN) }, size = 68.dp, repeat = true, container = btn, tint = tint)
        }
    }
}

@Composable
fun TouchPad(vm: RemoteViewModel) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(264.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(Unit) { detectTapGestures(onTap = { vm.key(Keys.CENTER) }) }
            .pointerInput(Unit) {
                var ax = 0f
                var ay = 0f
                val threshold = 70f
                detectDragGestures(
                    onDragStart = { ax = 0f; ay = 0f },
                    onDrag = { change, drag ->
                        change.consume()
                        ax += drag.x
                        ay += drag.y
                        if (abs(ax) > threshold) {
                            vm.key(if (ax > 0) Keys.RIGHT else Keys.LEFT)
                            ax = 0f; ay = 0f
                        } else if (abs(ay) > threshold) {
                            vm.key(if (ay > 0) Keys.DOWN else Keys.UP)
                            ax = 0f; ay = 0f
                        }
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "Vuốt để di chuyển\nChạm để chọn (OK)",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun NumPad(vm: RemoteViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        listOf(listOf(1, 2, 3), listOf(4, 5, 6), listOf(7, 8, 9)).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEach { n -> TextKeyBtn(n.toString(), { vm.key(Keys.digit(n)) }) }
            }
        }
        TextKeyBtn("0", { vm.key(Keys.digit(0)) })
    }
}

// =====================================================================
// Tab ứng dụng
// =====================================================================

@Composable
fun AppsTab(vm: RemoteViewModel, ui: UiState) {
    var query by rememberSaveable { mutableStateOf("") }
    var includeSystem by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(includeSystem) { vm.loadApps(includeSystem) }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                query, { query = it },
                modifier = Modifier.weight(1f),
                label = { Text("Tìm ứng dụng") },
                singleLine = true,
            )
            IconButton(onClick = { vm.loadApps(includeSystem) }) { Icon(Icons.Filled.Refresh, "Tải lại") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(includeSystem, { includeSystem = it })
            Spacer(Modifier.width(8.dp))
            Text("Hiện cả ứng dụng hệ thống")
        }
        if (ui.appsLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
        val list = remember(ui.apps, query) { ui.apps.filter { it.contains(query.trim(), ignoreCase = true) } }
        LazyColumn(Modifier.weight(1f)) {
            items(list, key = { it }) { pkg ->
                ListItem(
                    headlineContent = { Text(pkg) },
                    modifier = Modifier.clickable { vm.launchApp(pkg) },
                )
                HorizontalDivider()
            }
        }
    }
}

// =====================================================================
// Tab nhập liệu / lệnh nhanh / shell
// =====================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InputTab(vm: RemoteViewModel, ui: UiState) {
    var text by rememberSaveable { mutableStateOf("") }
    var cmd by rememberSaveable { mutableStateOf("") }
    var confirmReboot by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Gửi văn bản lên TV", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            text, { text = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Nội dung (ASCII, không dấu)") },
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.sendText(text); text = "" }) { Text("Gửi") }
            OutlinedButton(onClick = { vm.key(Keys.ENTER) }) { Text("Enter") }
            OutlinedButton(onClick = { vm.key(Keys.DEL) }) { Text("Xóa ⌫") }
        }

        HorizontalDivider()
        Text("Lệnh nhanh", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.runShell("am start -a android.settings.SETTINGS") }) { Text("Cài đặt") }
            OutlinedButton(onClick = { vm.runShell("am start -a android.settings.WIFI_SETTINGS") }) { Text("Wi-Fi") }
            OutlinedButton(onClick = { vm.runShell("am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS") }) { Text("Tùy chọn nhà phát triển") }
            OutlinedButton(onClick = { vm.runShell("input keyevent 224") }) { Text("Đánh thức") }
            OutlinedButton(onClick = { vm.runShell("input keyevent 223") }) { Text("Ngủ") }
            OutlinedButton(onClick = { confirmReboot = true }) { Text("Khởi động lại") }
        }

        HorizontalDivider()
        Text("Chạy lệnh shell", style = MaterialTheme.typography.titleSmall)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                cmd, { cmd = it },
                modifier = Modifier.weight(1f),
                label = { Text("vd: getprop ro.build.version.release") },
                singleLine = true,
            )
            Button(onClick = { vm.runShell(cmd) }) { Text("Chạy") }
        }
        Surface(
            Modifier.fillMaxWidth().heightIn(min = 140.dp),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
        ) {
            Text(
                if (ui.log.isEmpty()) "(chưa có kết quả)" else ui.log.joinToString("\n"),
                modifier = Modifier.padding(12.dp),
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }

    if (confirmReboot) {
        AlertDialog(
            onDismissRequest = { confirmReboot = false },
            title = { Text("Khởi động lại TV box?") },
            text = { Text("Kết nối sẽ bị ngắt, bạn cần kết nối lại sau khi TV box khởi động xong.") },
            confirmButton = {
                TextButton(onClick = { confirmReboot = false; vm.reboot() }) { Text("Khởi động lại") }
            },
            dismissButton = { TextButton(onClick = { confirmReboot = false }) { Text("Hủy") } },
        )
    }
}

// =====================================================================
// Tab chụp màn hình
// =====================================================================

@Composable
fun ScreenTab(vm: RemoteViewModel, ui: UiState) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Button(onClick = { vm.screenshot() }, enabled = !ui.shotLoading) {
            Icon(Icons.Filled.PhotoCamera, null)
            Spacer(Modifier.width(8.dp))
            Text(if (ui.shotLoading) "Đang chụp…" else "Chụp màn hình TV")
        }
        ui.screenshot?.let { bmp ->
            Spacer(Modifier.height(12.dp))
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Ảnh chụp màn hình TV",
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Fit,
            )
        }
    }
}
