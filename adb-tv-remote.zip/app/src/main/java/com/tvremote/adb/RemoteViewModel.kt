package com.tvremote.adb

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.IOException

data class UiState(
    val connected: Boolean = false,
    val connecting: Boolean = false,
    val deviceName: String = "",
    val host: String = "",
    val devices: List<SavedDevice> = emptyList(),
    val found: List<String> = emptyList(),
    val scanning: Boolean = false,
    val apps: List<String> = emptyList(),
    val appsLoading: Boolean = false,
    val screenshot: Bitmap? = null,
    val shotLoading: Boolean = false,
    val log: List<String> = emptyList(),
    val message: String? = null,
)

class RemoteViewModel(app: Application) : AndroidViewModel(app) {
    private val adb = AdbManager(app)
    private val store = DeviceStore(app)

    private val _ui = MutableStateFlow(UiState(devices = store.load()))
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    fun clearMessage() = _ui.update { it.copy(message = null) }

    // ---------- Kết nối ----------

    fun connect(host: String, port: Int) {
        val h = host.trim()
        if (h.isEmpty()) {
            _ui.update { it.copy(message = "Hãy nhập địa chỉ IP của TV box") }
            return
        }
        if (_ui.value.connecting) return
        viewModelScope.launch {
            _ui.update { it.copy(connecting = true) }
            adb.connect(h, port)
                .onSuccess { name ->
                    val list = store.upsert(SavedDevice(name, h, port))
                    _ui.update {
                        it.copy(
                            connected = true, connecting = false, deviceName = name,
                            host = "$h:$port", devices = list, apps = emptyList(),
                            screenshot = null, log = emptyList(),
                        )
                    }
                }
                .onFailure { e ->
                    _ui.update {
                        it.copy(connecting = false, message = "Kết nối thất bại: ${e.message ?: e}")
                    }
                }
        }
    }

    fun disconnect() {
        viewModelScope.launch {
            adb.disconnect()
            _ui.update { it.copy(connected = false) }
        }
    }

    fun forget(device: SavedDevice) {
        _ui.update { it.copy(devices = store.remove(device)) }
    }

    fun scan() {
        if (_ui.value.scanning) return
        viewModelScope.launch {
            _ui.update { it.copy(scanning = true, found = emptyList()) }
            val ok = LanScanner.scan(5555) { ip ->
                _ui.update { s ->
                    s.copy(found = (s.found + ip).distinct()
                        .sortedBy { addr -> addr.substringAfterLast('.').toIntOrNull() ?: 0 })
                }
            }
            _ui.update { s ->
                s.copy(
                    scanning = false,
                    message = when {
                        !ok -> "Không xác định được mạng Wi-Fi. Hãy kết nối Wi-Fi cùng mạng với TV."
                        s.found.isEmpty() -> "Không thấy thiết bị nào mở cổng 5555. Hãy bật ADB qua mạng trên TV box."
                        else -> null
                    },
                )
            }
        }
    }

    private fun fail(e: Throwable) {
        if (e is IOException) {
            viewModelScope.launch {
                adb.disconnect()
                _ui.update { it.copy(connected = false, message = "Mất kết nối: ${e.message ?: ""}") }
            }
        } else {
            _ui.update { it.copy(message = e.message ?: e.toString()) }
        }
    }

    // ---------- Điều khiển ----------

    // Hàng đợi phím: chỉ chạy 1 lệnh tại một thời điểm, các phím bấm dồn lại được gộp
    // thành một lệnh `input keyevent a b c` để TV box không bị quá tải.
    private val keyChannel = Channel<Int>(Channel.UNLIMITED)

    init {
        viewModelScope.launch {
            for (first in keyChannel) {
                val batch = mutableListOf(first)
                while (batch.size < 6) {
                    val next = keyChannel.tryReceive().getOrNull() ?: break
                    batch.add(next)
                }
                adb.sendKeys(batch).onFailure { fail(it) }
            }
        }
    }

    fun key(code: Int) {
        if (_ui.value.connected) keyChannel.trySend(code)
    }

    fun sendText(text: String) {
        if (text.isEmpty()) return
        val escaped = text.replace("'", "'\\''").replace(" ", "%s")
        viewModelScope.launch { adb.shell("input text '$escaped'").onFailure { fail(it) } }
    }

    fun runShell(cmd: String) {
        val c = cmd.trim()
        if (c.isEmpty()) return
        viewModelScope.launch {
            adb.shell(c)
                .onSuccess { out -> appendLog("$ $c", out.trimEnd()) }
                .onFailure { e ->
                    appendLog("$ $c", "Lỗi: ${e.message}")
                    fail(e)
                }
        }
    }

    fun benchmark() {
        viewModelScope.launch {
            appendLog("$ đo độ trễ", "Đang đo, chờ vài giây…")
            runCatching { adb.benchmark() }
                .onSuccess { lines -> appendLog("→ kết quả", lines.joinToString("\n")) }
                .onFailure { e ->
                    appendLog("→ kết quả", "Lỗi: ${e.message}")
                    fail(e)
                }
        }
    }

    fun reboot() {
        viewModelScope.launch {
            adb.shell("reboot")
            adb.disconnect()
            _ui.update { it.copy(connected = false, message = "Đang khởi động lại TV box…") }
        }
    }

    private fun appendLog(cmd: String, out: String) {
        _ui.update { s ->
            val lines = (s.log + cmd + out.lines()).takeLast(300)
            s.copy(log = lines)
        }
    }

    // ---------- Ứng dụng ----------

    fun loadApps(includeSystem: Boolean) {
        viewModelScope.launch {
            _ui.update { it.copy(appsLoading = true) }
            val cmd = if (includeSystem) "pm list packages" else "pm list packages -3"
            adb.shell(cmd)
                .onSuccess { out ->
                    val pkgs = out.lines()
                        .map { line -> line.trim() }
                        .filter { line -> line.startsWith("package:") }
                        .map { line -> line.removePrefix("package:") }
                        .sorted()
                    _ui.update { it.copy(apps = pkgs) }
                }
                .onFailure { fail(it) }
            _ui.update { it.copy(appsLoading = false) }
        }
    }

    fun launchApp(pkg: String) {
        if (!pkg.matches(Regex("[A-Za-z0-9._]+"))) return
        viewModelScope.launch {
            val r = adb.shell("monkey -p $pkg -c android.intent.category.LAUNCHER 1")
            val out = r.getOrNull().orEmpty()
            if (r.isSuccess && out.contains("No activities found")) {
                adb.shell("monkey -p $pkg -c android.intent.category.LEANBACK_LAUNCHER 1")
            }
            r.onFailure { fail(it) }
        }
    }

    // ---------- Chụp màn hình ----------

    fun screenshot() {
        if (_ui.value.shotLoading) return
        viewModelScope.launch {
            _ui.update { it.copy(shotLoading = true) }
            adb.screenshot()
                .onSuccess { bytes ->
                    val bmp = decodeScaled(bytes)
                    _ui.update {
                        it.copy(screenshot = bmp, message = if (bmp == null) "Không đọc được ảnh chụp" else null)
                    }
                }
                .onFailure { fail(it) }
            _ui.update { it.copy(shotLoading = false) }
        }
    }

    private fun decodeScaled(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val sample = (bounds.outWidth / 1920).coerceAtLeast(1)
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    override fun onCleared() {
        // Đóng kết nối khi app bị hủy hoàn toàn.
        kotlinx.coroutines.runBlocking { adb.disconnect() }
    }
}
