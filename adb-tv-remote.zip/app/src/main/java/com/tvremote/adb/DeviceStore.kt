package com.tvremote.adb

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedDevice(val name: String, val host: String, val port: Int)

class DeviceStore(context: Context) {
    private val sp = context.getSharedPreferences("devices", Context.MODE_PRIVATE)

    fun load(): List<SavedDevice> = runCatching {
        val arr = JSONArray(sp.getString("list", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SavedDevice(o.getString("name"), o.getString("host"), o.getInt("port"))
        }
    }.getOrDefault(emptyList())

    private fun write(list: List<SavedDevice>) {
        val arr = JSONArray()
        list.forEach { d ->
            arr.put(JSONObject().put("name", d.name).put("host", d.host).put("port", d.port))
        }
        sp.edit().putString("list", arr.toString()).apply()
    }

    fun upsert(device: SavedDevice): List<SavedDevice> {
        val list = load().filterNot { it.host == device.host && it.port == device.port } + device
        write(list)
        return list
    }

    fun remove(device: SavedDevice): List<SavedDevice> {
        val list = load().filterNot { it.host == device.host && it.port == device.port }
        write(list)
        return list
    }
}
