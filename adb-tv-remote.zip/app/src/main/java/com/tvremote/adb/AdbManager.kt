package com.tvremote.adb

import android.content.Context
import dadb.AdbKeyPair
import dadb.AdbShellStream
import dadb.Dadb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

class NotConnectedException : IOException("Chưa kết nối tới thiết bị")

class AdbManager(private val context: Context) {

    @Volatile
    private var dadb: Dadb? = null

    private fun keyPair(): AdbKeyPair {
        val priv = File(context.filesDir, "adbkey")
        val pub = File(context.filesDir, "adbkey.pub")
        if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
        return AdbKeyPair.read(priv, pub)
    }

    /** Kết nối tới TV box; trả về tên model. Có thể phải bấm "Cho phép" trên TV ở lần đầu. */
    suspend fun connect(host: String, port: Int): Result<String> = runCatching {
        disconnect()
        val kp = withContext(Dispatchers.IO) { keyPair() }
        val d = Dadb.create(host, port, kp)
        // Chạy ở scope riêng: lệnh blocking không hủy được, nên khi timeout ta đóng socket.
        val job = CoroutineScope(Dispatchers.IO).async {
            d.shell("getprop ro.product.model").output.trim()
        }
        val model = try {
            withTimeout(45_000) { job.await() }
        } catch (e: TimeoutCancellationException) {
            runCatching { d.close() }
            throw IOException("Hết thời gian chờ. Kiểm tra IP/cổng và bấm \"Cho phép\" trên TV.")
        } catch (e: Throwable) {
            runCatching { d.close() }
            throw e
        }
        dadb = d
        model.ifEmpty { host }
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        val d = dadb
        dadb = null
        runCatching { keyShell?.close() }
        keyShell = null
        if (d != null) runCatching { d.close() }
        Unit
    }

    // ---- Phiên shell giữ mở sẵn để gửi phím nhanh (không phải mở kết nối mới mỗi lần bấm) ----

    private val ackSem = Semaphore(0)

    @Volatile
    private var keyShell: AdbShellStream? = null

    private fun ensureKeyShell(d: Dadb): AdbShellStream {
        keyShell?.let { return it }
        val s = d.openShell()
        ackSem.drainPermits()
        keyShell = s
        Thread {
            try {
                while (true) {
                    val text = String(s.read().payload)
                    var idx = text.indexOf(MARK)
                    while (idx >= 0) {
                        ackSem.release()
                        idx = text.indexOf(MARK, idx + MARK.length)
                    }
                }
            } catch (_: Throwable) {
            }
            if (keyShell === s) keyShell = null
            ackSem.release(1000) // đánh thức bên đang chờ
        }.apply {
            isDaemon = true
            start()
        }
        return s
    }

    /** Gửi một hoặc nhiều phím trong một lệnh, qua phiên shell mở sẵn. */
    suspend fun sendKeys(codes: List<Int>): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val d = dadb ?: throw NotConnectedException()
            val cmd = "input keyevent ${codes.joinToString(" ")}"
            val s = try {
                ensureKeyShell(d)
            } catch (e: IOException) {
                keyShell = null
                throw e
            } catch (e: Exception) {
                null // thiết bị không hỗ trợ shell v2 -> dùng cách cũ
            }
            if (s == null) {
                d.shell(cmd)
            } else {
                try {
                    s.write("$cmd; echo $MARK\n")
                    if (!ackSem.tryAcquire(3, TimeUnit.SECONDS)) throw IOException("TV không phản hồi")
                } catch (e: IOException) {
                    keyShell = null
                    throw e
                }
            }
            Unit
        }
    }

    /** Đo thời gian từng cách gửi lệnh để biết bước nào gây trễ. */
    suspend fun benchmark(): List<String> = withContext(Dispatchers.IO) {
        val d = dadb ?: throw NotConnectedException()
        val out = mutableListOf<String>()
        fun timed(label: String, block: () -> Unit) {
            val start = System.nanoTime()
            val r = runCatching { block() }
            val ms = (System.nanoTime() - start) / 1_000_000
            out += if (r.isSuccess) "$label: $ms ms" else "$label: LỖI ${r.exceptionOrNull()?.message}"
        }
        fun viaOpenShell(cmd: String) {
            val s = ensureKeyShell(d)
            s.write("$cmd; echo $MARK\n")
            if (!ackSem.tryAcquire(5, TimeUnit.SECONDS)) throw IOException("quá 5 giây")
        }
        for (i in 1..3) timed("[A] shell mới: echo #$i") { d.shell("echo hi") }
        for (i in 1..3) timed("[B] shell mới: input keyevent #$i") { d.shell("input keyevent 0") }
        for (i in 1..3) timed("[C] phiên mở sẵn: echo #$i") { viaOpenShell("echo hi") }
        for (i in 1..3) timed("[D] phiên mở sẵn: input keyevent #$i") { viaOpenShell("input keyevent 0") }
        out
    }

    private companion object {
        const val MARK = "@@K@@"
    }

    suspend fun shell(cmd: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val d = dadb ?: throw NotConnectedException()
            d.shell(cmd).allOutput
        }
    }

    suspend fun screenshot(): Result<ByteArray> = withContext(Dispatchers.IO) {
        runCatching {
            val d = dadb ?: throw NotConnectedException()
            d.open("exec:screencap -p").use { stream ->
                stream.source.readByteArray()
            }
        }
    }
}

/** Quét mạng LAN /24 tìm thiết bị đang mở cổng ADB. */
object LanScanner {
    private fun localPrefix(): String? = runCatching {
        java.net.NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<java.net.Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }
            ?.hostAddress
            ?.substringBeforeLast('.')
    }.getOrNull()

    /** Trả về false nếu không xác định được mạng nội bộ. */
    suspend fun scan(port: Int = 5555, onFound: (String) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            val prefix = localPrefix() ?: return@withContext false
            kotlinx.coroutines.coroutineScope {
                (1..254).map { i ->
                    async {
                        val ip = "$prefix.$i"
                        try {
                            Socket().use { s ->
                                s.connect(InetSocketAddress(ip, port), 500)
                                onFound(ip)
                            }
                        } catch (_: Exception) {
                        }
                    }
                }.forEach { it.await() }
            }
            true
        }
}
