package com.tvremote.adb

import android.content.Context
import dadb.AdbKeyPair
import dadb.AdbShellStream
import dadb.Dadb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

class NotConnectedException : IOException("Chưa kết nối tới thiết bị")

class AdbManager(private val context: Context) {

    @Volatile
    private var dadb: Dadb? = null

    private fun keyPair(): AdbKeyPair {
        val priv = File(context.filesDir, "adbkey")
        val pub = File(context.filesDir, "adbkey.pub")
        if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
        return AdbKeyPair.read(priv, pub)
    }

    /** Kết nối tới TV box; trả về tên model. Có thể phải bấm "Cho phép" trên TV ở lần đầu. */
    suspend fun connect(host: String, port: Int): Result<String> = runCatching {
        disconnect()
        val kp = withContext(Dispatchers.IO) { keyPair() }
        val d = Dadb.create(host, port, kp)
        // Chạy ở scope riêng: lệnh blocking không hủy được, nên khi timeout ta đóng socket.
        val job = CoroutineScope(Dispatchers.IO).async {
            d.shell("getprop ro.product.model").output.trim()
        }
        val model = try {
            withTimeout(45_000) { job.await() }
        } catch (e: TimeoutCancellationException) {
            runCatching { d.close() }
            throw IOException("Hết thời gian chờ. Kiểm tra IP/cổng và bấm \"Cho phép\" trên TV.")
        } catch (e: Throwable) {
            runCatching { d.close() }
            throw e
        }
        dadb = d
        // Chuẩn bị sẵn kênh gửi phím nhanh ở nền để lần bấm đầu tiên không bị chờ.
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { ensureKeyChannel(d) }
        }
        model.ifEmpty { host }
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        val d = dadb
        dadb = null
        runCatching { keyShell?.close() }
        keyShell = null
        fastMode = false
        if (d != null) runCatching { d.close() }
        Unit
    }

    // =================================================================
    // Kênh gửi phím
    //
    // Lệnh `input keyevent` mỗi lần phải khởi động cả một tiến trình Java (~1 giây trên nhiều
    // TV box). Vì vậy app đẩy một tiến trình nhỏ (Injector) lên TV box, chạy sẵn và nhận phím
    // qua kết nối ADB đang mở (chế độ NHANH). Nếu không chạy được thì quay về dùng
    // `input keyevent` qua một phiên shell mở sẵn (chế độ THƯỜNG).
    // =================================================================

    private val ackSem = Semaphore(0)
    private val readySem = Semaphore(0)

    @Volatile
    private var keyShell: AdbShellStream? = null

    @Volatile
    private var fastMode = false

    @Volatile
    private var preparing = false

    private val diag = StringBuilder()

    private fun note(msg: String) {
        synchronized(diag) {
            if (diag.length < 1500) diag.append(msg.trim()).append('\n')
        }
    }

    private fun startReader(s: AdbShellStream) {
        Thread {
            try {
                while (true) {
                    val text = String(s.read().payload)
                    var rest = text
                    var idx = rest.indexOf(READY)
                    while (idx >= 0) {
                        readySem.release()
                        rest = rest.removeRange(idx, idx + READY.length)
                        idx = rest.indexOf(READY)
                    }
                    idx = rest.indexOf(MARK)
                    while (idx >= 0) {
                        ackSem.release()
                        rest = rest.removeRange(idx, idx + MARK.length)
                        idx = rest.indexOf(MARK)
                    }
                    if (rest.isNotBlank()) note(rest)
                }
            } catch (_: Throwable) {
            }
            if (keyShell === s) keyShell = null
            ackSem.release(1000) // đánh thức bên đang chờ
            readySem.release(1000)
        }.apply {
            isDaemon = true
            start()
        }
    }

    /** Thử khởi chạy Injector trên TV box. Trả về null nếu không được. */
    private fun startInjector(d: Dadb): AdbShellStream? {
        val apk = File(context.applicationInfo.sourceDir)
        val stamp = context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime
        val remote = "/data/local/tmp/tvremote_$stamp.apk"
        if (d.shell("ls $remote").exitCode != 0) {
            d.shell("rm -f /data/local/tmp/tvremote_*.apk")
            d.push(apk, remote)
        }
        val s = d.openShell("CLASSPATH=$remote app_process /system/bin com.tvremote.adb.Injector")
        ackSem.drainPermits()
        readySem.drainPermits()
        keyShell = s
        startReader(s)
        if (!readySem.tryAcquire(20, TimeUnit.SECONDS) || keyShell !== s) {
            runCatching { s.close() }
            if (keyShell === s) keyShell = null
            note("Injector không khởi động được")
            return null
        }
        return s
    }

    @Synchronized
    private fun ensureKeyChannel(d: Dadb): AdbShellStream {
        keyShell?.let { return it }
        preparing = true
        try {
            synchronized(diag) { diag.setLength(0) }
            val fast = try {
                startInjector(d)
            } catch (e: IOException) {
                note("Lỗi khởi chạy Injector: ${e.message}")
                null
            } catch (e: Exception) {
                note("Lỗi khởi chạy Injector: ${e.message}")
                null
            }
            if (fast != null) {
                fastMode = true
                return fast
            }
            fastMode = false
            val s = d.openShell()
            ackSem.drainPermits()
            readySem.drainPermits()
            keyShell = s
            startReader(s)
            return s
        } finally {
            preparing = false
        }
    }

    private fun sendKeysBlocking(d: Dadb, codes: List<Int>) {
        val list = codes.joinToString(" ")
        val cmd = "input keyevent $list"
        val s = if (preparing) {
            null // đang chuẩn bị kênh nhanh -> tạm dùng cách thường
        } else {
            try {
                ensureKeyChannel(d)
            } catch (e: IOException) {
                keyShell = null
                throw e
            } catch (e: Exception) {
                null // thiết bị không hỗ trợ shell v2 -> dùng cách thường
            }
        }
        if (s == null) {
            d.shell(cmd)
            return
        }
        try {
            s.write(if (fastMode) "k $list\n" else "$cmd; echo $MARK\n")
            if (!ackSem.tryAcquire(3, TimeUnit.SECONDS)) throw IOException("TV không phản hồi")
        } catch (e: IOException) {
            keyShell = null
            throw e
        }
    }

    /** Gửi một hoặc nhiều phím trong một lần. */
    suspend fun sendKeys(codes: List<Int>): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val d = dadb ?: throw NotConnectedException()
            sendKeysBlocking(d, codes)
        }
    }

    /** Đo thời gian từng cách gửi lệnh để biết bước nào gây trễ. */
    suspend fun benchmark(): List<String> = withContext(Dispatchers.IO) {
        val d = dadb ?: throw NotConnectedException()
        val out = mutableListOf<String>()
        fun timed(label: String, block: () -> Unit) {
            val start = System.nanoTime()
            val r = runCatching { block() }
            val ms = (System.nanoTime() - start) / 1_000_000
            out += if (r.isSuccess) "$label: $ms ms" else "$label: LỖI ${r.exceptionOrNull()?.message}"
        }
        for (i in 1..3) timed("[A] shell mới: echo #$i") { d.shell("echo hi") }
        for (i in 1..2) timed("[B] shell mới: input keyevent #$i") { d.shell("input keyevent 0") }
        // Chờ kênh nhanh chuẩn bị xong (lần đầu phải đẩy file lên TV box, có thể mất vài chục giây).
        val deadline = System.currentTimeMillis() + 60_000
        while (preparing && System.currentTimeMillis() < deadline) Thread.sleep(200)
        runCatching { sendKeysBlocking(d, listOf(0)) }
        out += "Chế độ gửi phím: " + if (fastMode) "NHANH (Injector)" else "THƯỜNG (input keyevent)"
        for (i in 1..5) timed("[C] gửi phím qua kênh chính #$i") { sendKeysBlocking(d, listOf(0)) }
        val info = synchronized(diag) { diag.toString().trim() }
        if (!fastMode && info.isNotEmpty()) out += "Lý do không dùng được chế độ nhanh:\n$info"
        out
    }

    private companion object {
        const val MARK = "@@K@@"
        const val READY = "@@READY@@"
    }

    suspend fun shell(cmd: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val d = dadb ?: throw NotConnectedException()
            d.shell(cmd).allOutput
        }
    }

    suspend fun screenshot(): Result<ByteArray> = withContext(Dispatchers.IO) {
        runCatching {
            val d = dadb ?: throw NotConnectedException()
            d.open("exec:screencap -p").use { stream ->
                stream.source.readByteArray()
            }
        }
    }
}

/** Quét mạng LAN /24 tìm thiết bị đang mở cổng ADB. */
object LanScanner {
    private fun localPrefix(): String? = runCatching {
        java.net.NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<java.net.Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }
            ?.hostAddress
            ?.substringBeforeLast('.')
    }.getOrNull()

    /** Trả về false nếu không xác định được mạng nội bộ. */
    suspend fun scan(port: Int = 5555, onFound: (String) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            val prefix = localPrefix() ?: return@withContext false
            kotlinx.coroutines.coroutineScope {
                (1..254).map { i ->
                    async {
                        val ip = "$prefix.$i"
                        try {
                            Socket().use { s ->
                                s.connect(InetSocketAddress(ip, port), 500)
                                onFound(ip)
                            }
                        } catch (_: Exception) {
                        }
                    }
                }.forEach { it.await() }
            }
            true
        }
}
