package com.tvremote.adb

import android.content.Context
import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

class NotConnectedException : IOException("Chưa kết nối tới thiết bị")

class AdbManager(private val context: Context) {

    @Volatile
    private var dadb: Dadb? = null

    private fun keyPair(): AdbKeyPair {
        val priv = File(context.filesDir, "adbkey")
        val pub = File(context.filesDir, "adbkey.pub")
        if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
        return AdbKeyPair.read(priv, pub)
    }

    /** Kết nối tới TV box; trả về tên model. Có thể phải bấm "Cho phép" trên TV ở lần đầu. */
    suspend fun connect(host: String, port: Int): Result<String> = runCatching {
        disconnect()
        val kp = withContext(Dispatchers.IO) { keyPair() }
        val d = Dadb.create(host, port, kp)
        // Chạy ở scope riêng: lệnh blocking không hủy được, nên khi timeout ta đóng socket.
        val job = CoroutineScope(Dispatchers.IO).async {
            d.shell("getprop ro.product.model").output.trim()
        }
        val model = try {
            withTimeout(45_000) { job.await() }
        } catch (e: TimeoutCancellationException) {
            runCatching { d.close() }
            throw IOException("Hết thời gian chờ. Kiểm tra IP/cổng và bấm \"Cho phép\" trên TV.")
        } catch (e: Throwable) {
            runCatching { d.close() }
            throw e
        }
        dadb = d
        model.ifEmpty { host }
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        val d = dadb
        dadb = null
        if (d != null) runCatching { d.close() }
        Unit
    }

    suspend fun shell(cmd: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val d = dadb ?: throw NotConnectedException()
            d.shell(cmd).allOutput
        }
    }

    suspend fun screenshot(): Result<ByteArray> = withContext(Dispatchers.IO) {
        runCatching {
            val d = dadb ?: throw NotConnectedException()
            d.open("exec:screencap -p").use { stream ->
                stream.source.readByteArray()
            }
        }
    }
}

/** Quét mạng LAN /24 tìm thiết bị đang mở cổng ADB. */
object LanScanner {
    private fun localPrefix(): String? = runCatching {
        java.net.NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<java.net.Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }
            ?.hostAddress
            ?.substringBeforeLast('.')
    }.getOrNull()

    /** Trả về false nếu không xác định được mạng nội bộ. */
    suspend fun scan(port: Int = 5555, onFound: (String) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            val prefix = localPrefix() ?: return@withContext false
            kotlinx.coroutines.coroutineScope {
                (1..254).map { i ->
                    async {
                        val ip = "$prefix.$i"
                        try {
                            Socket().use { s ->
                                s.connect(InetSocketAddress(ip, port), 500)
                                onFound(ip)
                            }
                        } catch (_: Exception) {
                        }
                    }
                }.forEach { it.await() }
            }
            true
        }
}
